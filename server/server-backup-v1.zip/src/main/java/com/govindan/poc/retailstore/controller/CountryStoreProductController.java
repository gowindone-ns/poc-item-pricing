package com.govindan.poc.retailstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.govindan.poc.retailstore.search.FromExpression;
import com.govindan.poc.retailstore.search.QueryPayload;
import com.govindan.poc.retailstore.service.CountryStoreProductService;
import com.govindan.poc.retailstore.service.SearchService;
import com.govindan.poc.retailstore.view.CountryStoreProductInfo;

@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
//TODO this is added only for dev purpose. Should be modified before shipping to production
public class CountryStoreProductController {
	@Autowired
	@Lazy
	private CountryStoreProductService service;

	@Autowired
	@Lazy
	private SearchService searchService;

	// TODO view model

	@GetMapping("/products/")
	public List<CountryStoreProductInfo> listAll() {

		return service.listAll();

	}

	@GetMapping("/products")
	public List<CountryStoreProductInfo> listByCountry(@RequestParam("countryCode") String countryCode) {

		return service.listByCountry(countryCode);
	}

	@PostMapping("/products/search")
	public List<CountryStoreProductInfo> search(@RequestBody QueryPayload queryPayload) {

		FromExpression fromExp = new FromExpression();
		fromExp.setEntity("CountryStoreProductInfo csp");

		// let us not expose table details to client
		// if accidentally received, let us override
		// to avoid SERIOUS security risk;
		queryPayload.getQuery().setFromExpression(fromExp);
		return searchService.searchCountryStoreProduct(queryPayload.getQuery());

	}

	@PutMapping("/products")
	public void save(@RequestBody CountryStoreProductInfo product) {

		service.save(product);
	}

	@PostMapping("/products")
	public void create(@RequestBody CountryStoreProductInfo product) {

		service.save(product);
	}
}
